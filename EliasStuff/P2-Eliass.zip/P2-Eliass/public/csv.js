const csv = require('csv-parser');
const fs = require('fs');

fs.createReadStream('public/Questionaire.csv')
  .pipe(csv())
  .on('data', (row) => {
    console.log(row);
  })
  .on('end', () => {
    console.log('CSV file successfully processed');
  });



const WritingToCsv = require('csv-writer').createObjectCsvWriter;
const csvObject = WritingToCsv({
  path: 'public/Questionaire.csv',
  header: [
    {id: 'id', title: 'ID'},
    {id: 'student', title: 'Student'},
    {id: 'question', title: 'Question'},
    {id: 'answer', title: 'Answer'},
  ]
});



//var myName2 = document.getElementById("AddTitle").value;
//console.log(myName2)


/*
const bab = "Icey1";



const data = [
  
  
  {
    id: 23234342,
    question: bab,
    answer: 'yes',
  }, {
    id: 34334,
    question: 'Question2?',
    answer: 'no',
  }, {
    id: 3,
    question: 'Question3?',
    answer: 'maybe',
  }
];




csvObject
  .writeRecords(data)
  .then(()=> console.log('The CSV file was written successfully', data[0].id));
*/

/*var onload = fetch("./Questionaire.csv").then(res => {
    return res.text()
}).then(data => {
    console.log(data);
});*/

module.exports = {fs, csv}


/*
let data = new Object();
data.id = int;
data.question = "";
data.answer = "";*/